HW3
===

1. Execution
Type `make` or `make all` to produce the three executables "bidding_system", "bidding_system_EDF", "customer".
Then execute `./bidding_system [testdata_path]` or `./bidding_system_EDF [testdata_path]` to run the program.

2. Self-Examination
I've finished all the grading criterias.

